#!/usr/bin/env bash

gradle clean

gradle assembleDebug

gradle assembleAndroidTest
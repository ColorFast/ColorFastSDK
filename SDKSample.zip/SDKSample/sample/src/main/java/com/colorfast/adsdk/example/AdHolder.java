package com.colorfast.adsdk.example;

/**
 * Created by Vincent
 *
 */
public class AdHolder {
    public static com.colorfast.kern.vo.AdsNativeVO adNativeVO = null;

}

package com.colorfast.adsdk.example.adapter;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;
import android.widget.TextView;

import com.colorfast.adsdk.example.R;
import com.colorfast.adsdk.example.bean.News;
import com.facebook.drawee.view.SimpleDraweeView;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by huangdong on 16/8/26.
 */
public class NormalRecyclerViewAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private LayoutInflater mLayoutInflater;
    private Context mContext;
    private List<News> aList;


    public NormalRecyclerViewAdapter(Context context) {
        aList = new ArrayList<>();
        mContext = context;
        mLayoutInflater = LayoutInflater.from(context);
    }


    @Override
    public int getItemViewType(int position) {
        News news = aList.get(position);
        if (news.isAds) {
            return 1;
        } else {
            return 2;
        }
    }


    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
//        if (viewType == 1) {  //ads
//            return new AdsViewHolder(
//                mLayoutInflater.inflate(R.layout.item_advance_ad_recycle, parent, false));
//        } else {    //
//            return new NormalTextViewHolder(
//                mLayoutInflater.inflate(R.layout.item_advance_ad_list, parent, false));
//        }

        return new NormalTextViewHolder(mLayoutInflater.inflate(R.layout.item_advance_ad_list, parent, false));

    }


    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
//        if (holder instanceof AdsViewHolder) {
//            News news = aList.get(position);
//            ViewGroup viewGroup = (ViewGroup) news.ctAdvanceNative.getParent();
//            if (viewGroup != null) {
//                viewGroup.removeViewInLayout(news.ctAdvanceNative);
//            }
//            ((AdsViewHolder) holder).ads_container.removeAllViews();
//            ((AdsViewHolder) holder).ads_container.addView(news.ctAdvanceNative);
//        } else if (holder instanceof NormalTextViewHolder) {
//            News news = aList.get(position);
//            ((NormalTextViewHolder) holder).icon.setImageURI(news.iconUrl);
//            ((NormalTextViewHolder) holder).tv_title.setText(news.title);
//            ((NormalTextViewHolder) holder).tv_desc.setText(news.desc);
//        }

        News news = aList.get(position);
        ((NormalTextViewHolder) holder).icon.setImageURI(news.iconUrl);
        ((NormalTextViewHolder) holder).tv_title.setText(news.title);
        ((NormalTextViewHolder) holder).tv_desc.setText(news.desc);

        if (news.isAds) {
            com.colorfast.kern.core.CFAdvanceNative ctAdvanceNative = news.ctAdvanceNative;
            ctAdvanceNative.registeADClickArea(((NormalTextViewHolder) holder).itemContainer);
        }

    }


    @Override
    public int getItemCount() {
        return aList == null ? 0 : aList.size();
    }


    public void setDate(List<News> dataList) {
        if (dataList != null) {
            aList = dataList;
        }

        notifyDataSetChanged();
    }


    public class AdsViewHolder extends RecyclerView.ViewHolder {
        RelativeLayout ads_container;


        public AdsViewHolder(View itemView) {
            super(itemView);

            ads_container = (RelativeLayout) itemView.findViewById(R.id.ads_container);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {

                }
            });

        }
    }


    public class NormalTextViewHolder extends RecyclerView.ViewHolder {
        View itemContainer;
        SimpleDraweeView icon;
        TextView tv_title;
        TextView tv_desc;


        NormalTextViewHolder(View view) {
            super(view);

            itemContainer = view.findViewById(R.id.itemContainer);
            icon = (SimpleDraweeView) view.findViewById(R.id.iv_icon);
            tv_title = (TextView) view.findViewById(R.id.tv_title);
            tv_desc = (TextView) view.findViewById(R.id.tv_desc);

            view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Log.d("NormalTextViewHolder", "onClick--> position = " + getPosition());
                }
            });
        }
    }

}

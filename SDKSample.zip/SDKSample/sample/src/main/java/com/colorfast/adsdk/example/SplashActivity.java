package com.colorfast.adsdk.example;

import android.app.Activity;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.Nullable;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.colorfast.adsdk.example.config.Config;
import com.colorfast.adsdk.example.listener.MyCTAdEventListener;
import com.facebook.drawee.view.SimpleDraweeView;
import com.colorfast.kern.core.ColorFastSDK;

/**
 * Created by huangdong on 17/4/13.
 */

public class SplashActivity extends Activity {


    private ViewGroup container;
    private ViewGroup adLayout;
    private TextView tv;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);


        tv = (TextView) findViewById(R.id.tv);
        container = (ViewGroup) findViewById(R.id.container);                                                  //媒体容器

        adLayout = (ViewGroup) View.inflate(SampleApplication.context, R.layout.advance_native_layout, null);  //广告布局
        loadAd();


        final CountDownTimer timer = new CountDownTimer(6200, 1000) {
            int num = 5;

            @Override
            public void onTick(long millisUntilFinished) {
                tv.setText("skip " + num);
                num--;
            }

            @Override
            public void onFinish() {
                finish();
            }
        };
        timer.start();

        tv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                timer.cancel();

                finish();

            }
        });

    }


    public void loadAd() {
        // 获取原生广告，返回一个含有广告的容器
        ColorFastSDK.getNativeAd(Config.slotIdNative, SampleApplication.context,
                new MyCTAdEventListener() {
                    @Override
                    public void onReceiveAdSucceed(com.colorfast.kern.core.CFNative result) {
                        if (result == null) {
                            return;
                        }
                        com.colorfast.kern.core.CFAdvanceNative ctAdvanceNative = (com.colorfast.kern.core.CFAdvanceNative) result;
                        showAd(ctAdvanceNative);
                        super.onReceiveAdSucceed(result);

                    }

                });
    }

    private void showAd(final com.colorfast.kern.core.CFAdvanceNative ctAdvanceNative) {
        SimpleDraweeView img = (SimpleDraweeView) adLayout.findViewById(R.id.iv_img);
        SimpleDraweeView icon = (SimpleDraweeView) adLayout.findViewById(R.id.iv_icon);
        TextView title = (TextView) adLayout.findViewById(R.id.tv_title);
        TextView desc = (TextView) adLayout.findViewById(R.id.tv_desc);
        TextView click = (TextView) adLayout.findViewById(R.id.bt_click);
        SimpleDraweeView ad_choice_icon = (SimpleDraweeView) adLayout.findViewById(
                R.id.ad_choice_icon);

        img.setImageURI(Uri.parse(ctAdvanceNative.getImageUrl()));
        icon.setImageURI(Uri.parse(ctAdvanceNative.getIconUrl()));
        title.setText(ctAdvanceNative.getTitle());
        desc.setText(ctAdvanceNative.getDesc());
        click.setText(ctAdvanceNative.getButtonStr());
        ad_choice_icon.setImageURI(ctAdvanceNative.getAdChoiceIconUrl());

        ctAdvanceNative.addADLayoutToADContainer(adLayout);
        ctAdvanceNative.registeADClickArea(adLayout);

        container.removeAllViews();
        container.addView(ctAdvanceNative);
    }

}

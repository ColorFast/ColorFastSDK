package com.colorfast.adsdk.example.utils;

/**
 * Created by jiantao.tu on 2018/3/19.
 */

public class Constants {

    public final static int TEST_COUNT = 6;
}

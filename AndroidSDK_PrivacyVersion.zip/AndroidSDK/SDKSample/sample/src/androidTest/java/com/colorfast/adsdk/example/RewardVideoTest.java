package com.colorfast.adsdk.example;

import android.support.test.espresso.DataInteraction;
import android.support.test.espresso.Espresso;
import android.support.test.espresso.UiController;
import android.support.test.espresso.ViewAction;
import android.support.test.filters.LargeTest;
import android.support.test.rule.ActivityTestRule;
import android.support.test.runner.AndroidJUnit4;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.widget.TextView;

import com.colorfast.adsdk.example.utils.RepeatRule;

import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.TypeSafeMatcher;
import org.junit.After;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Rule;
import org.junit.Test;
import org.junit.runner.RunWith;

import static android.support.test.espresso.Espresso.onData;
import static android.support.test.espresso.Espresso.onView;
import static android.support.test.espresso.action.ViewActions.click;
import static android.support.test.espresso.matcher.ViewMatchers.isAssignableFrom;
import static android.support.test.espresso.matcher.ViewMatchers.isDisplayed;
import static android.support.test.espresso.matcher.ViewMatchers.withId;
import static android.support.test.espresso.matcher.ViewMatchers.withText;
import static org.hamcrest.Matchers.allOf;
import static org.hamcrest.Matchers.anything;

/**
 * Created by tujiantao on 2018/3/5.
 */
@LargeTest
@RunWith(AndroidJUnit4.class)
public class RewardVideoTest {

    private final static String TAG = "RewardVideoTest";

    @Rule
    public RepeatRule repeatRule = new RepeatRule();

    @Rule
    public ActivityTestRule<MainActivity> mActivityTestRule = new ActivityTestRule<>(MainActivity
            .class);


    private SimpleCountingIdlingResource preloadAdIdlingResource;

    private SimpleCountingIdlingResource showAdIdlingResource;

    @BeforeClass
    public static void startClass(){
        SimpleCountingIdlingResource initIdlingResource = SimpleCountingIdlingResource.create("test1");
//        IdlingPolicies.setMasterPolicyTimeout(100, TimeUnit.SECONDS);
//        IdlingPolicies.setIdlingResourceTimeout(100, TimeUnit.SECONDS);
        Espresso.registerIdlingResources(initIdlingResource);
        Espresso.unregisterIdlingResources(initIdlingResource);
    }

    @Before
    public void start() throws Exception {

        final MainActivity activity = mActivityTestRule.getActivity();
//        if (!PowersUtil.getScreenOn(activity) || PowersUtil.getLockScreenOn(activity)) {//解锁屏幕
//            PowersUtil.wakeUpAndUnlock(activity);
//        }
        Thread.sleep(1000);
        DataInteraction appCompatTextView = onData(anything())
                .inAdapterView(allOf(withId(R.id.listView),
                        childAtPosition(withId(R.id.main_content), 0))).atPosition(7);
        appCompatTextView.perform(click());
        Thread.sleep(5000);
    }

    @Test
    @RepeatRule.Repeat( runCount = 3 )
    public void execute() throws Exception {
        String statusLabel = getText(withId(R.id.statusLabel));
        int count=0;
        while(!statusLabel.contains("Rewarded video loaded")){
            if(count>60){
                return;
            }
            onView(allOf(withId(R.id.loadButton), withText("Preload"), isDisplayed())).perform(click());
            preloadAdIdlingResource = SimpleCountingIdlingResource.create("test2");
            Espresso.registerIdlingResources(preloadAdIdlingResource);
            Espresso.unregisterIdlingResources(preloadAdIdlingResource);
            Thread.sleep(6000);
            statusLabel = getText(withId(R.id.statusLabel));
            count++;
        }
        Log.i(TAG, "视频预加载成功");
        onView(allOf(withId(R.id.showButton),withText("Show"),isDisplayed())).perform(click());
        Thread.sleep(45000);
        showAdIdlingResource= SimpleCountingIdlingResource.create("test3");
        Espresso.registerIdlingResources(showAdIdlingResource);
        Log.i(TAG,"视频播放错误或者完成了");
        Espresso.unregisterIdlingResources(showAdIdlingResource);

    }

    @After
    public void stop() {
    }


    private static Matcher<View> childAtPosition(
            final Matcher<View> parentMatcher, final int position) {

        return new TypeSafeMatcher<View>() {
            @Override
            public void describeTo(Description description) {
                description.appendText("Child at position " + position + " in parent ");
                parentMatcher.describeTo(description);
            }

            @Override
            public boolean matchesSafely(View view) {
                ViewParent parent = view.getParent();
                return parent instanceof ViewGroup && parentMatcher.matches(parent)
                        && view.equals(((ViewGroup) parent).getChildAt(position));
            }
        };
    }

    public String getText(final Matcher<View> matcher) {
        final String[] text = {null};
        onView(matcher).perform(new ViewAction() {
            //识别所操作的对象类型
            @Override
            public Matcher<View> getConstraints() {
                return isAssignableFrom(TextView.class);
            }
            //视图操作的一个描述
            @Override
            public String getDescription() {
                return "getting text from a TextView";
            }
            //实际的一个操作，在之类我们就可以获取到操作的对象了。
            @Override
            public void perform(UiController uiController, View view) {
                TextView textView = (TextView)view;
                text[0] = textView.getText().toString();
            }
        });
        return text[0];
    }

}

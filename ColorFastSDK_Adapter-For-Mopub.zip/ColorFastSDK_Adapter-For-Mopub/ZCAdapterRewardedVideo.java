package com.colorfast.mediation.mopub;

import android.app.Activity;
import android.support.annotation.NonNull;
import android.util.Log;

import com.colorfast.kern.core.CFVideo;
import com.mopub.common.LifecycleListener;
import com.mopub.common.MoPubReward;
import com.mopub.common.logging.MoPubLog;
import com.mopub.mobileads.CustomEventRewardedVideo;
import com.mopub.mobileads.MoPubErrorCode;
import com.mopub.mobileads.MoPubRewardedVideoManager;
import com.colorfast.kern.callback.VideoAdLoadListener;
import com.colorfast.kern.core.ColorFastSDK;
import com.colorfast.kern.core.CFError;
import com.colorfast.video.core.RewardedVideoAdListener;
import com.colorfast.video.core.ColorFastVideo;

import java.util.Map;

public class ZCAdapterRewardedVideo extends CustomEventRewardedVideo {
    private CFVideo video;
    private String adUnitId;

    private static final String TAG = "CTAdapterRewardedVideo";

    @Override
    @NonNull
    public LifecycleListener getLifecycleListener() {
        return new LifecycleListener() {
            @Override
            public void onCreate(@NonNull Activity activity) {

            }


            @Override
            public void onStart(@NonNull Activity activity) {

            }


            @Override
            public void onPause(@NonNull Activity activity) {

            }


            @Override
            public void onResume(@NonNull Activity activity) {

            }


            @Override
            public void onRestart(@NonNull Activity activity) {

            }


            @Override
            public void onStop(@NonNull Activity activity) {

            }


            @Override
            public void onDestroy(@NonNull Activity activity) {

            }


            @Override
            public void onBackPressed(@NonNull Activity activity) {

            }
        };
    }


    @Override
    @NonNull
    public String getAdNetworkId() {
        return adUnitId;
    }


    @Override
    public boolean checkAndInitializeSdk(@NonNull final Activity launcherActivity,
                                         @NonNull final Map<String, Object> localExtras,
                                         @NonNull final Map<String, String> serverExtras) {
        Log.e(TAG, "checkAndInitializeSdk: localExtras -> " + localExtras + ", serverExtras -> " +
            serverExtras);
        if (!com.colorfast.mediation.mopub.ZCHelper.extrasAreValid(serverExtras)) {
            return false;
        }
        String adUnitId = serverExtras.get(com.colorfast.mediation.mopub.ZCHelper.KEY_CT_SLOTID);
        ColorFastSDK.initialize(launcherActivity, adUnitId);
        return true;
    }


    @Override
    protected void loadWithSdkInitialized(@NonNull Activity activity,
                                          @NonNull Map<String, Object> localExtras,
                                          @NonNull Map<String, String> serverExtras) {
        Log.e(TAG, "loadWithSdkInitialized: localExtras -> " + localExtras + ", serverExtras -> " +
            serverExtras);
        if (!com.colorfast.mediation.mopub.ZCHelper.extrasAreValid(serverExtras)) {
            MoPubRewardedVideoManager.onRewardedVideoLoadFailure(ZCAdapterRewardedVideo.class, "",
                MoPubErrorCode.NETWORK_NO_FILL);
            return;
        }
        adUnitId = serverExtras.get(com.colorfast.mediation.mopub.ZCHelper.KEY_CT_SLOTID);

        ColorFastVideo.preloadRewardedVideo(activity, adUnitId,
            new VideoAdLoadListener() {
                @Override
                public void onVideoAdLoadSucceed(CFVideo videoAd) {
                    video = videoAd;
                    MoPubRewardedVideoManager.onRewardedVideoLoadSuccess(
                        ZCAdapterRewardedVideo.class, adUnitId);
                }


                @Override
                public void onVideoAdLoadFailed(CFError error) {
                    MoPubRewardedVideoManager.onRewardedVideoLoadFailure(
                        ZCAdapterRewardedVideo.class, adUnitId,
                        MoPubErrorCode.NETWORK_NO_FILL);
                }

            });
    }


    @Override
    public boolean hasVideoAvailable() {
        return ColorFastVideo.isRewardedVideoAvailable(video);
    }


    @Override
    public void showVideo() {
        if (hasVideoAvailable()) {
            ColorFastVideo.showRewardedVideo(video, new RewardedVideoAdListener() {

                @Override
                public void videoStart() {
                    MoPubRewardedVideoManager.onRewardedVideoStarted(ZCAdapterRewardedVideo.class,
                        adUnitId);
                }

                @Override
                public void videoFinish() {
                }

                @Override
                public void videoError(Exception e) {
                    MoPubRewardedVideoManager.onRewardedVideoPlaybackError(
                        ZCAdapterRewardedVideo.class, adUnitId, MoPubErrorCode.VIDEO_NOT_AVAILABLE);
                }

                @Override
                public void videoClosed() {
                    MoPubRewardedVideoManager.onRewardedVideoClosed(ZCAdapterRewardedVideo.class,
                        adUnitId);
                }


                @Override
                public void videoClicked() {
                    MoPubRewardedVideoManager.onRewardedVideoClicked(ZCAdapterRewardedVideo.class,
                        adUnitId);
                }


                @Override
                public void videoRewarded(String rewardName, String rewardAmount) {
                    int amount = 0;
                    try {
                        amount = Integer.parseInt(rewardAmount);
                    } catch (NumberFormatException e) {
                        e.printStackTrace();
                    }
                    MoPubRewardedVideoManager.onRewardedVideoCompleted(ZCAdapterRewardedVideo.class,
                        adUnitId,
                        MoPubReward.success(rewardName, amount));
                }

            });
        } else {
            MoPubLog.d("Attempted to show rewarded video before it was available.");
        }
    }


    @Override
    protected void onInvalidate() {
        video = null;
    }

}
